package main

import (
	"aoc2021/d1"
	"fmt"
)

func main() {
	// D1
	fmt.Println(d1.Increment())
}
