## Description

This repo contains my solutions to 2021 AoC (Advent of Code) challenges.

More info about [AoC](https://en.wikipedia.org/wiki/Advent_of_Code)